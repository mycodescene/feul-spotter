"""Routes management package."""
